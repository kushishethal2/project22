class rope{
	constructor()
	{

	//create rope constraint here

	}


    //create display() here 

}
